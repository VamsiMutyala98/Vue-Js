<template>
<div>
    <body class="Dashboard">
        <div class="container">
            <table class="table table-striped table-lg mt-5" style="background-color: white;">
                <thead id="fun">
                    <tr class="SA">
                        <th colspan="3"><span class="some">Qproducts</span> List</th>
                    </tr>
                    <tr style="font-size:medium;" class="SA1">
                        <th >S.No</th>
                        <th >Product Name</th>
                        <th >Product Price</th>
                    </tr>
                </thead>
                <tbody  id="table_Id">
                    <tr>
                        <td>1.</td>
                        <td>OPPO F19</td>
                        <td>Rs:18,000/-</td>
                    </tr>
                    <tr>
                        <td>2.</td>
                        <td>Samsung Galaxy F12</td>
                        <td>Rs:9,999/-</td>
                    </tr>
                    <tr>
                        <td>3.</td>
                        <td>Realme 8 Pro</td>
                        <td>Rs:19,150/-</td>
                    </tr>
                    <tr>
                        <td>4.</td>
                        <td>OnePlus 9 Pro</td>
                        <td>Rs:64,999/-</td>
                    </tr>
                    <tr>
                        <td>5.</td>
                        <td>Xiaomi Redmi Note 10</td>
                        <td>Rs:11,999/-</td>
                    </tr>
                    <tr>
                        <td>6.</td>
                        <td>Vivo X60 Pro</td>
                        <td>Rs:49,990/-</td>
                    </tr>
                </tbody>
            </table>
            <br>
            <br>
            <ul id="unOrderedList">
                <li v-for="team in teams" :key="team">
                    <b>Name:</b>{{team.teamName}} <b>Captain:</b>{{team.captain}}
                    <b>Points:</b>{{team.points}}
                    <h1 v-if="team.points>=200">Eligible for PlayOff</h1>
                    <h1 v-else>Not Eligible for PlayOff</h1>
                </li>
            </ul>
        </div>
    </body>
</div>
</template>

<script>
export default {
  name: 'Dashboard',
  data() {
    return {
      teams: [
        {
          teamName: 'RCB',
          captain: 'Virat Kohili',
          points: '200',
        },
        {
          teamName: 'Mumbai',
          captain: 'Rohit Sharma',
          points: '190',
        },
        {
          teamName: 'Chennai',
          captain: 'Ms Dhoni',
          points: '220',
        },
      ],
    };
  },
};
</script>

<style scoped>
            .container{
                text-align: left;
                padding:50px 0px 0px 10%;
                margin-right: 10%;
            }
            table{
                width:100%
            }
            h1{
                font-size: 38px;
            }
            h1::first-letter{
                color:green;
                font-size: 50px;
            }
            #table_id{
                font-family: sans-serif;
            }
            #vis1{
                display: none;
            }
            .SA{
                background-color: rgb(58, 58, 114);
                font-size: large;
                color: white;
                height: 50px;
            }
            .some{
                font-size: xx-large;
                padding-left: 10px;
            }
</style>
