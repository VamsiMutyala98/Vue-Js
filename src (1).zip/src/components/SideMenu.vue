<template>
    <div>
        <header>
            <router-link class="same" to="/">Home</router-link>
            <router-link class="same" to="/login">Login</router-link>
            <router-link class="same" to="/dashboard">Dashboard</router-link>
        </header>
    </div>
</template>
<style scoped>
div{
    text-align: right;
}
.same{
    padding-right: 15px;
}
</style>
