<template>
    <div class="same">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <div class="same x"><h2>Qproducts</h2></div>
        <div class="same">
            <input class="fun" type="text" placeholder="Search Anything You Want..." name="box">
            <a class="search-button" href="#"><i class="fa fa-search"></i></a>
        </div>
    <div class="same">
        <SideMenu />
    </div>
    </div>
</template>
<script>
import SideMenu from './SideMenu.vue';

export default {
  components: { SideMenu },
  name: 'Header',
  component: {
    SideMenu,
  },
};
</script>
<style scoped>
.same{
    margin: -15px;
    margin-top: -30px;
}
.fun{
    font-family: sans-serif;
    border: 3px solid black;
    border-right: 0;
    height: 30px;
    width:300px;
    padding: 0px 10px;
}
h2{
    text-align: left;
}
h2::first-letter{
    color: green;
    font-size: 40px;
}
a{
    padding: 1.5px 7px 5px 7px ;
    border: 3px solid black;
}
.x{
    padding-left: 10px;
}
</style>
