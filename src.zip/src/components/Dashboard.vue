<template>
<div>
    <body class="Dashboard">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <div class="container">
            <table class="table table-striped table-lg mt-5" style="background-color: white;">
                <thead id="fun">
                    <tr class="SA">
                        <th colspan="3"><span class="some">Qproducts</span> List</th>
                    </tr>
                    <tr style="font-size:medium;">
                        <th >S.No</th>
                        <th >Product Name</th>
                        <th >Product Price</th>
                    </tr>
                </thead>
                <tbody  id="table_Id">
                    <tr>
                        <td>1.</td>
                        <td>OPPO F19</td>
                        <td>Rs:18,000/-</td>
                    </tr>
                    <tr>
                        <td>2.</td>
                        <td>Samsung Galaxy F12</td>
                        <td>Rs:9,999/-</td>
                    </tr>
                    <tr>
                        <td>3.</td>
                        <td>Realme 8 Pro</td>
                        <td>Rs:19,150/-</td>
                    </tr>
                    <tr>
                        <td>4.</td>
                        <td>OnePlus 9 Pro</td>
                        <td>Rs:64,999/-</td>
                    </tr>
                    <tr>
                        <td>5.</td>
                        <td>Xiaomi Redmi Note 10</td>
                        <td>Rs:11,999/-</td>
                    </tr>
                    <tr>
                        <td>6.</td>
                        <td>Vivo X60 Pro</td>
                        <td>Rs:49,990/-</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</div>
</template>
<style scoped>
            h1{
                font-size: 38px;
            }
            h1::first-letter{
                color:green;
                font-size: 50px;
            }
            #table_id{
                font-family: sans-serif;
            }
            #vis1{
                display: none;
            }
            .SA{
                background-color: rgb(58, 58, 114);
                font-size: large;
                color: white;
            }
            .some{
                font-size: xx-large;
            }
</style>
