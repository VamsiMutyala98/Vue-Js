<template>
    <div>
        <v-container>
            <h1 class="my-5">Get The Data</h1>
            <v-btn @click="postData" class="green depressed white--text mr-3"><v-icon>mdi-post</v-icon>Post The Data</v-btn>
            <v-btn @click="deleteData(no)" class="red depressed white--text mr-3"><v-icon>mdi-delete</v-icon>Delete The Data</v-btn>
            <v-btn @click="putData" class="blue depressed white--text mr-3"><v-icon>mdi-pencil</v-icon>Put The Data</v-btn>
            <div v-if="todos.length===0">No Tasks </div>
                <div v-else >
                <div >
                    <v-card  class="my-10 float-left mr-5" max-width="350" min-height="400" v-for="(todo,i) of todos" :key="i">
                        <img :src="todo.thumbnailUrl" alt="" height="260" width="350">
                        <v-card-title>{{todo.title}}</v-card-title>
                    </v-card>
                </div>
            </div>

        </v-container>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'get',
    data() {
        return {
            loading: true,
            todos: [],
            no: 10,
        };
    },
    mounted(){
        this.getData();
    },
    methods: {
        async postData() {
            try {
                const payload={
                    userId:11,
                    title:'payload title',
                }
                await axios.post('https://jsonplaceholder.typicode.com/albums',payload).then(()=>{
                    this.getData();
                });
                console.log("success");
            } catch (error) {
                console.log('error')
            }
        },
        async putData() {
            try {
                const payload={
                    userId:10,
                    title:'payload title',
                    body: 'payload body',
                    id:100,
                };
                await axios.post('https://jsonplaceholder.typicode.com/albums',payload).then(()=>{
                    this.getData();
                });
            } catch (error) {
                console.log('error')
            }
        },
        async deleteData(id) {
            try {
                await axios.delete('https://jsonplaceholder.typicode.com/albums/'+id).then(()=>{
                    this.getData();
                })
                console.log("success")
            } catch (error) {
                console.log(error);
            }
        },
        async getData(){
            this.loading=true;
            try {
                const response=await axios.get('https://jsonplaceholder.typicode.com/photos');
                this.todos=response.data;
                this.loading=false;
                console.log(this.todos)
            } catch (error) {
                console.log("error");
                this.loading=false;
            }
        }
    }
};
</script>
<style scoped>
.some{
    margin-left: 10%;
    margin-right: 10%;
    float:left;
}
</style>
