<template>
    <div>
        <v-container>
            <h1 class="my-5">API</h1>
            <v-btn @click="postData" class="green depressed white--text mr-3"><v-icon>mdi-post</v-icon>Post The Data</v-btn>
            <v-btn @click="deleteData(no)" class="red depressed white--text mr-3"><v-icon>mdi-delete</v-icon>Delete The Data</v-btn>
            <v-btn @click="putData" class="blue depressed white--text mr-3"><v-icon>mdi-pencil</v-icon>Put The Data</v-btn>
            <div v-if="todos.length===0">No Tasks </div>
                <div v-else >
                <div >
                    <v-card  class="my-10 float-left mr-5" max-width="350" min-height="450" v-for="(todo,i) of todos" :key="i">
                        <img :src="todo.thumbnailUrl" alt="" height="260" width="350">
                        <v-card-title v-if="todo.title.length<32">{{todo.title}}<span class="white--text">asdfghjklmnxbcvzkwjsdahjkasdfghjklmnxbcvzkwjsdahjk</span></v-card-title>
                        <v-card-title v-else-if="todo.title.length<66">{{todo.title}}<span class="white--text">asdfghjklmnxbcvzkwjsdahjk</span></v-card-title>
                        <v-card-title v-else>{{todo.title}}</v-card-title>
                        <v-btn @click="putData" class="blue depressed white--text mr-5"><v-icon>mdi-pencil</v-icon>Update</v-btn>
                        <v-btn @click="deleteData(todo.id)" class="red depressed white--text mr-3"><v-icon>mdi-delete</v-icon>Delete</v-btn>
                    </v-card>
                </div>
            </div>

        </v-container>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'get',
    data() {
        return {
            loading: true,
            todos: [],
            no: 10,
        };
    },
    mounted(){
        this.getData();
    },
    methods: {
        async postData() {
            try {
                const payload={
                    "albumId": 1,
                    "title": "Payload title",
                    "url": "https://via.placeholder.com/600/92c952",
                    "thumbnailUrl": "https://via.placeholder.com/150/92c952"
                    }
                await axios.post('https://jsonplaceholder.typicode.com/albums',payload)
                    this.todos.push(payload);
                    window.console.log('success');
                    window.console.log(payload);
                    console.log(this.todos)
                console.log("success");
            } catch (error) {
                console.log('error')
            }
        },
        async putData() {
            try {
                const payload={
                    albums: 1,
                    id: 2,
                    title: 'Upadated payload',
                    url: 'https://via.placeholder.com/600/92c952',
                    thumbnailUrl: 'https://via.placeholder.com/150/92c952',
                };
                await axios.put('https://jsonplaceholder.typicode.com/albums/'+payload.id,payload).then(()=>{
                    this.getData();

                });
            } catch (error) {
                console.log('error')
            }
        },
        async deleteData(id) {
            try {
                await axios.delete(`https://jsonplaceholder.typicode.com/photos/${id}`).then(()=>{
                    this.getData();
                })
                console.log("success")
            } catch (error) {
                console.log(error);
            }
        },
        async getData(){
            this.loading=true;
            try {
                const response=await axios.get('https://jsonplaceholder.typicode.com/photos');
                this.todos=response.data;
                this.loading=false;
                console.log(this.todos)
            } catch (error) {
                console.log("error");
                this.loading=false;
            }
        }
    }
};
</script>
