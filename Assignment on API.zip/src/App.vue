<template>
  <v-app class="white">
    <v-main class="white mt-5 subheading text-center">
        <router-link class="mr-5 black--text text-decoration-none" to='/'><v-btn><v-icon>mdi-home</v-icon>Home</v-btn></router-link>
        <router-link class="mr-5 black--text text-decoration-none" to='/about'><v-btn><v-icon>mdi-feather</v-icon>About</v-btn></router-link>
        <router-link class="mr-5 black--text text-decoration-none" to='/api'><v-btn><v-icon>mdi-network</v-icon>API</v-btn></router-link>
        <router-view />
    </v-main>
  </v-app>
</template>

<script>

export default {
  name: 'App',
};
</script>
