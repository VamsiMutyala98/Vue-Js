import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../components/Home.vue'
import listRendering from '../components/listRendering.vue';
import computed from '../components/computed.vue';
import Watcher from '../components/Watcher.vue';
import vuetify from '../components/vuetify.vue';
import SCSS from '../components/SCSS.vue';
import lifeCycleMethods from '../components/lifeCycleMethods.vue';  
import dyanmicClasses from '../components/dyanmic-classes.vue';
import mixin from '../components/mixin.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/listRendering',
    name: 'listRendering',
    component: listRendering,
  },
  {
    path: '/computed',
    name: 'computed',
    component: computed
  },
  {
    path: '/watcher',
    name: 'Watcher',
    component: Watcher
  },
  {
    path: '/dyanmic-classes',
    name: 'dyanmicClasses',
    component: dyanmicClasses,
  },
  {
    path: '/SCSS',
    name: 'SCSS',
    component: SCSS
  },
  {
    path: '/mixin',
    name: 'mixin',
    component: mixin,
  },
  {
    path: '/vuetify',
    name: 'vuetify',
    component: vuetify,
  },
  {
    path: '/lifeCycleMethods',
    name: 'lifeCycleMethods',
    component: lifeCycleMethods,
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
