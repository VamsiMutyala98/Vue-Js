<template>
    <div>
        <h1>List & Conditional Rendering in vue js</h1>
        <ul id="unOrderedList">
                <li v-for="team in teams" :key="team">
                    <b>Name:</b>{{team.teamName}} <b>Captain:</b>{{team.captain}}
                    <b>Points:</b>{{team.points}}
                    <h1 v-if="team.points>=200">Eligible for PlayOff</h1>
                    <h1 v-else>Not Eligible for PlayOff</h1>
                </li>
            </ul>
    </div>
</template>
<script>
export default {
  name: 'Dashboard',
  data() {
    return {
      teams: [
        {
          teamName: 'RCB',
          captain: 'Virat Kohili',
          points: '200',
        },
        {
          teamName: 'Mumbai',
          captain: 'Rohit Sharma',
          points: '190',
        },
        {
          teamName: 'Chennai',
          captain: 'Ms Dhoni',
          points: '220',
        },
      ],
    };
  },
};
</script>
<style scoped>
li{
    text-align: left;
    text-decoration: none;
    list-style: none;
}
h1{
    color: green;
}
ul li h1 {
    color: red;
}
</style>
