<template>
    <div>
        <button v-on:mouseover="increment">On Mouse Over</button>
        <h2>Count: {{count}}</h2>
    </div>
</template>
<script>
import CounterMixin from './Mixins/CounterMixin.js';

export default {
    name: 'onMouseOver',
    mixins: [CounterMixin]
};
</script>
<style scoped>
button{
    padding: 20px;
}
</style>
