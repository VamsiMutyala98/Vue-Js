<template>
    <div>
        <h1>Mixin</h1>
        <onclick />
        <onMouseOver />
    </div>
</template>
<script>
import onclick from './onclick.vue';
import onMouseOver from './onMouseOver.vue';

export default {
    name: 'mixin',
    components: {
        onclick,
        onMouseOver,
    },
};
</script>