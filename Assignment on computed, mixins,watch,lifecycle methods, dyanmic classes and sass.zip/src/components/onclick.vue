<template>
    <div>
        <button v-on:click="increment">On Click</button>
        <h2>Count: {{count}}</h2>
    </div>
</template>
<script>
import CounterMixin from './Mixins/CounterMixin.js';

export default {
    name: 'onclick',
    mixins: [CounterMixin]
};
</script>
<style scoped>
button{
    padding: 20px;
}
</style>
