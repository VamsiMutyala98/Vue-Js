<template>
    <div>
        <h1>SCSS in vue js</h1>
        <div class="Idiv">
            <h1>Inside Div</h1>
            <h2>Inside Div</h2>
            <h3>Inside Div</h3>
        </div>
        <div class="Odiv"><h1>Outside Div</h1></div>
    </div>
</template>
<script>
export default {
    name: 'SCSS',
};
</script>
<style scoped lang="scss">
.Idiv{
    text-align: left;
    padding-left: 20px;
}
.Idiv h1{
    color: red;
}
.Idiv h2{
    color: green;
}
.Idiv h3 {
    color: blue;
}
.Odiv  h1{
    color:palevioletred;
    text-align: left;
    padding-left: 20px;
}
</style>