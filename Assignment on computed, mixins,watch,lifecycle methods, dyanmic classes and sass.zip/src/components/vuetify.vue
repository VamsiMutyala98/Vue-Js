<template>
    <div>
        <h1>vuetify in vue js</h1>
    </div>
</template>
<script>
export default {
    name: 'vuetify',
};
</script>