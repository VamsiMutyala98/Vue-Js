<template>
    <div>
        <h1>Watcher in vue js</h1>
        <label>Enter Your Name: </label>
        <input type="text" v-model="message">
        <h2 id="fun">NewValue: Empty</h2>
        <h2 id='fun1'>OldValue: Empty</h2>
    </div>
</template>
<script>
export default {
    name: 'Watcher',
    data() {
        return {
            message: '',
        }
    },
    watch: {
        message(newValue, oldValue) {
            document.getElementById('fun1').innerHTML='NewValue: '+newValue;
            document.getElementById('fun').innerHTML='OldValue: '+oldValue;
            return oldValue;
        }
    }
};
</script>