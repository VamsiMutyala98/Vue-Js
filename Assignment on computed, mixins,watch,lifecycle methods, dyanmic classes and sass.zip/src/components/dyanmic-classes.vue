<template>
    <div>
        <h1>Dyanmic classes</h1>
        <button v-on:click="red = !red" v-bind:class="{available: red}">Dyanmic classes Testing</button>
    </div>
</template>
<script>
export default {
    name: 'dyanmicClasses',
    data() {
        return {
            red:true,
        }
    },
};
</script>
<style scoped>
button{
    background-color: red;
}
.available {
    background-color: green;
    padding: 10px;
}
</style>