<template>
    <div>
        <h1>Life Cycle Methods in vue js</h1>
        <div class="fun">
            <h2>1.BeforeCreate(beforeCreate): </h2>
            <p>Called immediately after the instance has been initialized, before data observation and event/watcher setup.</p>
            <h2>2.created: </h2>
            <p>Called synchronously after the instance is created. At this stage, the instance has finished processing the options which means the following have been set up: data observation, computed properties, methods, watch/event callbacks. However, the mounting phase has not been started, and the $el property will not be available yet.</p>
            <h2>3.BeforeMount(beforeMount): </h2>
            <p>Called right before the mounting begins: the render function is about to be called for the first time.</p>
            <h2>4.mounted: </h2>
            <p>Called after the instance has been mounted, where element, passed to app.mount is replaced by the newly created vm.$el. If the root instance is mounted to an in-document element, vm.$el will also be in-document when mounted is called.</p>
            <h2>5.BeforeUpdate(beforeUpdate): </h2>
            <p>Called when data changes, before the DOM is patched. This is a good place to access the existing DOM before an update, e.g. to remove manually added event listeners.</p>
            <h2>6.updated:</h2>
            <p>Called after a data change causes the virtual DOM to be re-rendered and patched.
                The component's DOM will have been updated when this hook is called, so you can perform DOM-dependent operations here. However, in most cases you should avoid changing state inside the hook. To react to state changes, it's usually better to use a computed property or watcher instead.</p>
            <h2>7.beforeDestroy: </h2>  
            <p>Called right before a component instance is unmounted. At this stage the instance is still fully functional.</p>   
            <h2>8.Destroyed: </h2>  
            <p>Called after a component instance has been unmounted. When this hook is called, all directives of the component instance have been unbound, all event listeners have been removed, and all child component instance have also been unmounted.</p>
            <h2>Checking</h2>
        </div>
    </div>
</template>
<script>
export default {
    name: 'lifeCycleMethods',
    data() {
        return {
            name: 'Vamsi',
        }
    },
    beforeCreate() {
        console.log("Before created");
    },
    created() {
        console.log("created");
    },
    beforeMount() {
        console.log("Before Mounted");
    },
    mounted() {
        console.log("Mounted");
    },
    beforeUpdate() {
        console.log("Before Created");
    },
    updated() {
        console.log("Created");
    },
    beforeDestroy() {
        console.log("Before Destroyed");
    },
    destroyed() {
        console.log("Destroyed");
    }
};
</script>
<style scoped>
.fun{
    text-align: left;
    padding-left: 20px;
}
p{
    padding-left: 50px;
}
</style>