<template>
    <div>
        <ul>
            <li><router-link class="same" to="/">Home</router-link></li>
            <li><router-link class="same" to="/About">About</router-link></li>
            <li><router-link class="same" to="/listRendering">listRendering</router-link></li>
            <li><router-link class="same" to="/computed">computed</router-link></li>
            <li><router-link class="same" to="/watcher">Watcher</router-link></li>
            <li><router-link class="same" to="/dyanmic-classes">Dyanmic classes</router-link></li>
            <li><router-link class="same" to="/SCSS">SCSS</router-link></li>
            <li><router-link class="same" to="/mixin">Mixin</router-link></li>
            <li><router-link class="same" to="/lifeCycleMethods">Life Cycle Methods</router-link></li>
            <li><router-link class="same" to="/vuetify">Vuetify</router-link></li>
        </ul>
    </div>
</template>
<script>
export default {
    name: 'sideMenu',
};
</script>
<style scoped>
li{
    list-style: none;
    text-align: left;
    padding-bottom: 10px;
}
.same:hover{
    color: oldlace;
    text-decoration: underline;
    font-size: 20px;
}
.same{
    text-decoration: None;
    font-weight: bold;
    color: white;
}
</style>