<template>
    <div>
        <h1>Computed in vue js</h1>
        <h2>Score: {{Score}}</h2>
        <h2>Wickets: {{Wickets}}</h2>
        <h2>Overs: {{Overs}}</h2>
        <button v-on:click="score++" @click="increment">One Run</button>
        <button v-on:click="score=score+2" @click="increment">Two Runs</button>
        <button v-on:click="score=score+3" @click="increment">Three Runs</button>
        <button v-on:click="score=score+4" @click="increment">Four</button>
        <button v-on:click="score=score+6" @click="increment">Six</button>
        <button v-on:click="wickets++" @click="increment">Wickets</button>
    </div>
</template>
<script>
export default {
    name: 'computed',
    data() {
        return {
            score: 0,
            wickets: 0,
            overs: 0,
            count:0,
        }
    },
    methods: {
        increment() {
            if(((this.overs.toFixed(1))%10)*10==this.count+5){
                this.count += 10
                this.overs += 0.5;
            }
            else{
                this.overs = this.overs+0.1;
            }
        }
    },
    computed: {
        Score() {
            return this.score
        },
        Wickets() {
            return this.wickets
        },
        Overs() {
            return (this.overs).toFixed(1);
        },
    }
};
</script>
<style scoped>
button{
    margin-right: 20px;
}
h1::first-letter{
    color: green;
    font-size: 40px;
}
</style>