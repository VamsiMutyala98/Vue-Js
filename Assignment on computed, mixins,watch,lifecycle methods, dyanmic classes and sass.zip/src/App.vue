<template>
  <div id="app">
    <div id="nav" class="rou">
      <sideMenu />
    </div>
    <div class="same rou">
      <router-view/>
    </div>
  </div>
</template>
<script>
import sideMenu from './components/sideMenu.vue';

export default {
  name: 'App',
  components: {
    sideMenu,
  },
}
</script>
<style scoped>
*{
  margin: 0;
  padding: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 25px;
  width: 10%;
  color: white;
  background-color: gray;
  margin-top:-8px;
  margin-left: -8px;
  height: 1000px;
}

#nav a {
  font-weight: bold;
  text-decoration-color: white;
  color: white;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
.same {
  width: 80%;
  margin-right: 20px;
  margin-top:-8px;
  margin-left: -8px;
}
.rou{
  float: left;
}
</style>
